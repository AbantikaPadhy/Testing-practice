$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"cb4f936a-6c5c-4bed-a59b-1d01ace18931","feature":"Test the starHealth page on Chrome Browser","scenario":"Validate the Star Health Buy Now flow","start":1698148666371,"group":1,"content":"","tags":"","end":1698148744733,"className":"failed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});