package com.app.junitDemo;
import org.junit.jupiter.api.Test;
public class TestAnnotation {

	@Test  // execute the below test
	public void Method1()  // unit Test method
	{
		System.out.println("Hello Junit");
	}
}
