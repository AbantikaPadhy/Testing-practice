package com.app.junitDemo;

public class JavaOperations {

}
